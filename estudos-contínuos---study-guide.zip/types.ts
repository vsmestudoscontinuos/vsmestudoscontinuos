
export interface StudyEntry {
  id: string;
  date: string;
  subject: string;
  content: string;
  theory_done: boolean;
  questions_done: boolean;
  law_doctrine_done: boolean;
  active_review_done: boolean;
  questions_count: number;
  pomodoro_count: number; // New field
  study_hours: number;
  study_minutes: number;
  study_seconds?: number; // Novo campo para precisão
  created_at: string;
  data_de_consentimento?: string;
  versao_da_politica?: string;
}

export interface User {
  id: string;
  email: string;
  full_name: string;
  trial_accepted: boolean;
  trial_end_date: string;
  is_premium: boolean;
  premium_expires_at?: string;
  data_de_consentimento: string;
  versao_da_politica: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  last_reviewed?: string;
  next_review?: string;
  level: number; // For Spaced Repetition (0-5)
}

export interface FlashcardDeck {
  id: string;
  subject: string;
  content: string;
  cards: Flashcard[];
  created_at: string;
}

export interface ActiveStudy {
  id: string;
  date: string;
  subject: string;
  topic: string;
  method: 'recall' | 'explanation' | 'mindmap' | 'other';
  notes: string;
  completed: boolean;
}
