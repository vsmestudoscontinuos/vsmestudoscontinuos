
import React, { useState, useEffect } from 'react';
import { Settings, Plus, LogOut, LayoutDashboard, Layers, BrainCircuit, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import CalendarGrid from '../components/CalendarGrid';
import MonthlyProgressChart from '../components/MonthlyProgressChart';
import StudyEntryForm from '../components/StudyEntryForm';
import StudyEntryList from '../components/StudyEntryList';
import FlashcardManager from '../components/FlashcardManager';
import FlashcardReview from '../components/FlashcardReview';
import ActiveStudyTracker from '../components/ActiveStudyTracker';
import Logo from '../components/Logo';
import { StudyEntry, User, FlashcardDeck, Flashcard, ActiveStudy } from '../types';

interface Props {
  user: User | null;
  onLogout: () => void;
}

type Tab = 'dashboard' | 'flashcards' | 'active-study';

const Home: React.FC<Props> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [showForm, setShowForm] = useState(false);
  const [entries, setEntries] = useState<StudyEntry[]>([]);
  const [decks, setDecks] = useState<FlashcardDeck[]>([]);
  const [activeStudies, setActiveStudies] = useState<ActiveStudy[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [reviewingDeck, setReviewingDeck] = useState<FlashcardDeck | null>(null);

  // Load data from localStorage
  useEffect(() => {
    const storedEntries = localStorage.getItem('study_entries');
    const storedDecks = localStorage.getItem('study_decks');
    const storedActiveStudies = localStorage.getItem('active_studies');

    if (storedEntries) setEntries(JSON.parse(storedEntries));
    if (storedDecks) setDecks(JSON.parse(storedDecks));
    if (storedActiveStudies) setActiveStudies(JSON.parse(storedActiveStudies));
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('study_entries', JSON.stringify(entries));
    localStorage.setItem('study_decks', JSON.stringify(decks));
    localStorage.setItem('active_studies', JSON.stringify(activeStudies));
  }, [entries, decks, activeStudies]);

  const daysEntries = entries.filter(e => e.date === selectedDate);

  const handleSaveEntry = (newEntry: any) => {
    const entry: StudyEntry = {
      ...newEntry,
      id: Math.random().toString(36).substr(2, 9),
      created_at: new Date().toISOString(),
      data_de_consentimento: user?.data_de_consentimento,
      versao_da_politica: user?.versao_da_politica
    };
    setEntries([entry, ...entries]);
    setShowForm(false);
  };

  const handleDeleteEntry = (id: string) => {
    setEntries(prevEntries => prevEntries.filter(entry => entry.id !== id));
  };

  const handleDeleteAllForDay = () => {
    if (window.confirm('ATENÇÃO: Deseja excluir TODOS os registros deste dia? Esta ação não pode ser desfeita.')) {
      setEntries(prevEntries => prevEntries.filter(entry => entry.date !== selectedDate));
    }
  };

  // Flashcard Handlers
  const handleSaveDeck = (deck: FlashcardDeck) => {
    setDecks([deck, ...decks]);
  };

  const handleDeleteDeck = (id: string) => {
    if (window.confirm('Excluir este deck de flashcards?')) {
      setDecks(decks.filter(d => d.id !== id));
    }
  };

  const handleCompleteReview = (deckId: string, updatedCards: Flashcard[]) => {
    setDecks(decks.map(d => d.id === deckId ? { ...d, cards: updatedCards } : d));
    setReviewingDeck(null);
  };

  // Active Study Handlers
  const handleAddActiveStudy = (study: ActiveStudy) => {
    setActiveStudies([study, ...activeStudies]);
  };

  const handleToggleActiveStudy = (id: string) => {
    setActiveStudies(activeStudies.map(s => s.id === id ? { ...s, completed: !s.completed } : s));
  };

  const handleDeleteActiveStudy = (id: string) => {
    setActiveStudies(activeStudies.filter(s => s.id !== id));
  };

  return (
    <div className="bg-slate-50 min-h-screen pb-32">
      <header className="bg-white border-b border-slate-100 sticky top-0 z-30">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo className="w-10 h-10" showText={false} />
            <div>
              <h1 className="font-extrabold text-[#1E3A8A] text-lg leading-none">VSM</h1>
              <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider mt-1">Study Guide</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/contact" title="Configurações e Contato" className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-600">
              <Settings className="h-5 w-5" />
            </Link>
            <button 
              onClick={onLogout}
              title="Sair do Aplicativo"
              className="text-red-500 hover:bg-red-50 p-2 rounded-xl transition-all"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-in fade-in duration-500">
            <CalendarGrid 
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              entries={entries}
            />

            <MonthlyProgressChart 
              entries={entries}
            />

            {/* Active Study Summary Card */}
            {activeStudies.filter(s => s.date === selectedDate).length > 0 && (
              <div 
                onClick={() => setActiveTab('active-study')}
                className="bg-white border border-emerald-100 rounded-[32px] p-6 shadow-sm hover:shadow-md transition-all cursor-pointer group"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600">
                      <BrainCircuit className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-800">Objetivos Ativos de Hoje</h3>
                  </div>
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1 rounded-lg">
                    {activeStudies.filter(s => s.date === selectedDate && s.completed).length} / {activeStudies.filter(s => s.date === selectedDate).length}
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full transition-all duration-700" 
                    style={{ 
                      width: `${(activeStudies.filter(s => s.date === selectedDate && s.completed).length / activeStudies.filter(s => s.date === selectedDate).length) * 100}%` 
                    }}
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-3 font-medium flex items-center gap-1">
                  Clique para gerenciar seus estudos ativos <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </p>
              </div>
            )}

            <div className="flex items-center justify-between mt-8">
              <div className="flex items-center gap-3">
                 <h2 className="text-xl font-bold text-[#1E3A8A]">Registros do Dia</h2>
                 {daysEntries.length > 0 && !showForm && (
                    <button
                        onClick={handleDeleteAllForDay}
                        className="text-[10px] font-bold text-red-400 hover:text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-all uppercase tracking-wider"
                        title="Excluir todos do dia"
                    >
                        Limpar Dia
                    </button>
                 )}
              </div>
              <button 
                onClick={() => setShowForm(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-md shadow-blue-200"
              >
                <Plus className="w-4 h-4" />
                Novo Registro
              </button>
            </div>

            {showForm ? (
              <StudyEntryForm 
                onSave={handleSaveEntry}
                onCancel={() => setShowForm(false)}
                initialDate={selectedDate}
              />
            ) : (
              <StudyEntryList 
                entries={daysEntries}
                selectedDate={selectedDate}
                onDelete={handleDeleteEntry}
              />
            )}
          </div>
        )}

        {activeTab === 'flashcards' && (
          <div className="animate-in fade-in duration-500">
            <FlashcardManager 
              decks={decks}
              onSaveDeck={handleSaveDeck}
              onDeleteDeck={handleDeleteDeck}
              onReviewDeck={setReviewingDeck}
            />
          </div>
        )}

        {activeTab === 'active-study' && (
          <div className="animate-in fade-in duration-500">
            <ActiveStudyTracker 
              studies={activeStudies}
              onAddStudy={handleAddActiveStudy}
              onToggleStudy={handleToggleActiveStudy}
              onDeleteStudy={handleDeleteActiveStudy}
              selectedDate={selectedDate}
            />
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/80 backdrop-blur-md border border-slate-100 px-4 py-3 rounded-[32px] shadow-2xl flex items-center gap-2 z-40">
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === 'dashboard' ? 'bg-[#1E3A8A] text-white shadow-lg shadow-blue-100' : 'text-slate-400 hover:bg-slate-50'}`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className={activeTab === 'dashboard' ? 'block' : 'hidden'}>Dashboard</span>
        </button>
        <button 
          onClick={() => setActiveTab('flashcards')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === 'flashcards' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-400 hover:bg-slate-50'}`}
        >
          <Layers className="w-5 h-5" />
          <span className={activeTab === 'flashcards' ? 'block' : 'hidden'}>Flashcards</span>
        </button>
        <button 
          onClick={() => setActiveTab('active-study')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === 'active-study' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'text-slate-400 hover:bg-slate-50'}`}
        >
          <BrainCircuit className="w-5 h-5" />
          <span className={activeTab === 'active-study' ? 'block' : 'hidden'}>Estudo Ativo</span>
        </button>
      </nav>

      {reviewingDeck && (
        <FlashcardReview 
          deck={reviewingDeck}
          onClose={() => setReviewingDeck(null)}
          onComplete={handleCompleteReview}
        />
      )}
    </div>
  );
};

export default Home;
